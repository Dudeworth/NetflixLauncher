USE AT YOUR OWN RISK!  

I take no responsibility for anything this program does to your computer.  This was written in AutoIT and I encourage you to read the script in the au3 file.

This is workaround for netflix in XBMC using the Advanced launcher.  It assumes you have XBMC with Advanced Launcher installed from the  Angelscry Repo.  It also assumes you have a mouse with a 3rd button (or wheel click)

1. unzip to the C:\ (path for the executable must be C:\NetflixLauncher\NetflixLauncher.exe)
2. In XBMC, use Advanced Launcher to point to NetflixLauncher.exe

Using the script:
After launching the executable, firefox opens full screen.  
Use the middle click to popup an on screen keyboard.  
Right clicking will close the window and return to XBMC.

The majority of what this program does was written by others, I just hacked it together.  I tried to credit in the code who I took from.

  --Dudeworth

